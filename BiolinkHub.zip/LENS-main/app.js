const express = require('express');
const app = express();
const path = require('path');
const session = require('express-session');
const bodyParser = require('body-parser');
const { connectDB } = require('./db');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1y',
  etag: true,
  immutable: true
}));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'biolink-secret',
  resave: false,
  saveUninitialized: true
}));

app.use((req, res, next) => {
  res.set('Cache-Control', 'no-cache, must-revalidate');
  next();
});

// Database integration
/*
• Jasa pembuatan website 
• Menerima perbaikan script atau fitur bot
• Menerima pembuatan fitur bot
• Menerima semua kebutuhan bot
• Menerima dia dengan segala kekurangannya;)
ℹ️ Information

• Bisa bayar di awal atau akhir
• Pembayaran melalu QRIS Only
• Testimoni Banyak

Kontak: wa.me/6282389924037
t.me/VynaaValerie
*/
let db;
const dbPromise = connectDB().then(database => {
  db = database;
  return db;
});

// Middleware to ensure DB is connected
app.use(async (req, res, next) => {
  if (!db) {
    await dbPromise;
  }
  next();
});

// Admin Authentication Middleware
const isAdmin = (req, res, next) => {
  if (req.session.isAdmin) return next();
  res.redirect('/admin/login');
};

// Admin Routes
app.get('/admin/login', (req, res) => {
  res.render('admin_login');
});

app.post('/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === 'AdminLens123') { // Simple default password
    req.session.isAdmin = true;
    res.redirect('/admin');
  } else {
    res.render('admin_login', { error: 'Invalid password' });
  }
});
/*
• Jasa pembuatan website 
• Menerima perbaikan script atau fitur bot
• Menerima pembuatan fitur bot
• Menerima semua kebutuhan bot
• Menerima dia dengan segala kekurangannya;)
ℹ️ Information

• Bisa bayar di awal atau akhir
• Pembayaran melalu QRIS Only
• Testimoni Banyak

Kontak: wa.me/6282389924037
t.me/VynaaValerie
*/
app.get('/admin/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

app.get('/admin', isAdmin, async (req, res) => {
  const config = await db.collection('settings').findOne({ type: 'web_config' });
  const customPages = await db.collection('custom_pages').find({}).toArray();
  res.render('admin_dashboard', { config, customPages });
});

app.post('/admin/config', isAdmin, async (req, res) => {
  const { 
    webName, profilePhoto, backgroundPhoto, musicUrl, links, 
    posterPhoto, imagePhoto, image2Photo,
    seoTitle, seoDescription, seoKeywords,
    profileSubtitle, profileBio,
    welcomeText, payments, testimonials, qrisUrl
  } = req.body;
  
  // Clean links array
  const formattedLinks = [];
  if (links) {
    Object.keys(links).forEach(key => formattedLinks.push(links[key]));
  }

  // Clean payments array
  const formattedPayments = [];
  if (payments) {
    Object.keys(payments).forEach(key => formattedPayments.push(payments[key]));
  }

  // Clean testimonials array
  const formattedTestimonials = [];
  if (testimonials) {
    Object.keys(testimonials).forEach(key => formattedTestimonials.push(testimonials[key]));
  }

  await db.collection('settings').updateOne(
    { type: 'web_config' },
    { $set: { 
      webName, 
      profilePhoto, 
      backgroundPhoto, 
      musicUrl, 
      links: formattedLinks,
      payments: formattedPayments,
      testimonials: formattedTestimonials,
      qrisUrl,
      posterPhoto,
      imagePhoto,
      image2Photo,
      seoTitle,
      seoDescription,
      seoKeywords,
      profileSubtitle,
      profileBio,
      welcomeText
    } }
  );
  res.redirect('/admin?success=true');
});

// Payment & Testimonials page
app.get('/pay-testi', async (req, res) => {
  const config = await db.collection('settings').findOne({ type: 'web_config' });
  res.render('pay&testi', { config });
});

// Splash page
app.get('/', async (req, res) => {
  const config = await db.collection('settings').findOne({ type: 'web_config' });
  res.render('splash', { config });
});

// Main biolink page
app.get('/main', async (req, res) => {
  const config = await db.collection('settings').findOne({ type: 'web_config' });
  res.render('index', { 
    biolinks: config.links,
    config: config
  });
});

// Custom Pages Admin Routes
app.get('/admin/pages', isAdmin, async (req, res) => {
  const pages = await db.collection('custom_pages').find({}).toArray();
  res.render('admin_pages', { pages });
});

app.post('/admin/pages', isAdmin, async (req, res) => {
  const { route, title, content } = req.body;
  
  // Clean route - ensure it starts with /
  const cleanRoute = route.startsWith('/') ? route : '/' + route;
  
  // Check if route already exists
  const existing = await db.collection('custom_pages').findOne({ route: cleanRoute });
  if (existing) {
    await db.collection('custom_pages').updateOne(
      { route: cleanRoute },
      { $set: { title, content, updatedAt: new Date() } }
    );
  } else {
    await db.collection('custom_pages').insertOne({
      route: cleanRoute,
      title,
      content,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }
  
  res.redirect('/admin?success=true');
});

app.post('/admin/pages/delete', isAdmin, async (req, res) => {
  const { route } = req.body;
  await db.collection('custom_pages').deleteOne({ route });
  res.redirect('/admin?success=true');
});

// REST API - Get all biolinks
app.get('/api/biolinks', (req, res) => {
  res.json({
    success: true,
    data: biolinks,
    total: biolinks.length
  });
});

// REST API - Get popular biolinks (first 2)
app.get('/api/biolinks/popular', (req, res) => {
  const popularLinks = biolinks.slice(0, 2);
  res.json({
    success: true,
    data: popularLinks,
    total: popularLinks.length
  });
});

// Dynamic Custom Pages Route (must be last before 404)
app.get('/:customRoute', async (req, res, next) => {
  const route = '/' + req.params.customRoute;
  const page = await db.collection('custom_pages').findOne({ route });
  
  if (page) {
    const config = await db.collection('settings').findOne({ type: 'web_config' });
    try {
      const ejs = require('ejs');
      const renderedContent = ejs.render(page.content, { config });
      res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${page.title} | ${config.webName}</title>
          <link rel="stylesheet" href="/styles.css">
          <style>
            body { font-family: 'Inter', sans-serif; background: #0f172a; color: #f8fafc; min-height: 100vh; padding: 2rem; }
            .custom-page { max-width: 800px; margin: 0 auto; }
            .back-btn { display: inline-flex; align-items: center; gap: 0.5rem; color: #a855f7; text-decoration: none; margin-bottom: 1.5rem; }
            .back-btn:hover { text-decoration: underline; }
          </style>
        </head>
        <body>
          <div class="custom-page">
            <a href="/main" class="back-btn">&larr; Back to Main</a>
            ${renderedContent}
          </div>
        </body>
        </html>
      `);
    } catch (err) {
      res.status(500).send('Error rendering page: ' + err.message);
    }
  } else {
    next();
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Biolink server running on http://0.0.0.0:${PORT}`);
});

/*
• Jasa pembuatan website 
• Menerima perbaikan script atau fitur bot
• Menerima pembuatan fitur bot
• Menerima semua kebutuhan bot
• Menerima dia dengan segala kekurangannya;)
ℹ️ Information

• Bisa bayar di awal atau akhir
• Pembayaran melalu QRIS Only
• Testimoni Banyak

Kontak: wa.me/6282389924037
t.me/VynaaValerie
*/