const { MongoClient } = require('mongodb');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, 'env.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const uri = config.MONGODB_URI;
const client = new MongoClient(uri);
/*
• Jasa pembuatan website 
• Menerima perbaikan script atau fitur bot
• Menerima pembuatan fitur bot
• Menerima semua kebutuhan bot
• Menerima dia dengan segala kekurangannya;)
ℹ️ Information

• Bisa bayar di awal atau akhir
• Pembayaran melalu QRIS Only
• Testimoni Banyak

Kontak: wa.me/6282389924037
t.me/VynaaValerie
*/

// Ini boleh d ganti
let db;

async function connectDB() {
  if (db) return db;
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    db = client.db('biolink');
    
    const settings = db.collection('settings');
    const existing = await settings.findOne({ type: 'web_config' });
    
    const defaultLinks = [
      {
        title: 'Bocoran Event Mlbb',
        url: 'https://whatsapp.com/channel/0029VbBZz3ULCoX0OoFi9H3A',
        icon: 'fa-gamepad'
      },
      {
        title: 'Marketplace Pterodactyl dan produk digital',
        url: 'https://baeci-host.xyz/',
        icon: 'fa-store'
      },
      {
        title: 'Rest Api Fitur Terbaik',
        url: '/api/biolinks',
        icon: 'fa-code'
      },
      {
        title: 'Kumpulan Penjoki V1',
        url: 'https://chat.whatsapp.com/BIoKVGO9VrU08NcdZOZIMj?mode=ems_copy_t',
        icon: 'fa-users'
      },
      {
        title: 'Kumpulan Penjoki V2',
        url: 'https://chat.whatsapp.com/HM0FRns47Uy3upSL4JFqUY?mode=ems_copy_t',
        icon: 'fa-users'
      },
      {
        title: 'Tongkrongan Penjoki V1',
        url: 'https://chat.whatsapp.com/B5DfZ7H0EUjHQZuY7oGcmj?mode=ems_copy_t',
        icon: 'fa-people-group'
      },
      {
        title: 'Tongkrongan Penjoki V2',
        url: 'https://chat.whatsapp.com/I7jQAPChrd18d6vUezgZpE?mode=ems_copy_t',
        icon: 'fa-people-group'
      },
      {
        title: 'Party ilmu Hitam V1',
        url: 'https://chat.whatsapp.com/J8vHC9RS77X18zZh04lhtp?mode=ems_copy_t',
        icon: 'fa-star'
      },
      {
        title: 'Preman Classic V2',
        url: 'https://chat.whatsapp.com/El1ERBPNRskDzfU5tv9nYh?mode=ems_copy_t',
        icon: 'fa-crown'
      },
      {
        title: 'Preman Classic V3',
        url: 'https://chat.whatsapp.com/CnPjCjCcSaF5QPtD9yTrbj?mode=ems_copy_t',
        icon: 'fa-crown'
      },
      {
        title: 'Preman Classic V4',
        url: 'https://chat.whatsapp.com/If4xn17q1lHF5B07UaV0pM?mode=ems_copy_t',
        icon: 'fa-crown'
      },
      {
        title: 'Preman Classic V5',
        url: 'https://chat.whatsapp.com/ER6G2XBPwUW36CkE4WlvUR?mode=ems_copy_t',
        icon: 'fa-crown'
      },
      {
        title: 'ALL LINK FULL BOT WA',
        url: 'https://whatsapp.com',
        icon: 'fa-robot'
      },
      {
        title: 'Streaming Drama, Anime & Cinema Gratis',
        url: 'https://nonton-yuk.zone.id/',
        icon: 'fa-film'
      }
    ];

    const defaultPayments = [
      { name: 'DANA', number: '087761601481', holder: 'olvat a.r' },
      { name: 'GOPAY', number: '087761601481', holder: 'olvat a.r' },
      { name: 'OVO', number: '087761601481', holder: 'olvat a.r' },
      { name: 'SHOPEE PAY', number: '087761601481', holder: 'olvat a.r' },
      { name: 'BANK JAGO', number: '104787618564', holder: 'olvat a.r' },
      { name: 'SEA BANK', number: '901905541737', holder: 'olvat a.r' }
    ];

    const defaultTestimonials = [
      { name: 'Rizky Ganteng', comment: 'Gila sih, prosesnya cepet banget ga sampe 5 menit langsung kelar. Recommended seller!', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Siti Aminah', comment: 'Awalnya ragu, tapi ternyata amanah banget. CS nya juga ramah pol!', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Budi Santoso', comment: 'Panel Pterodactyl-nya kenceng, ga ada kendala sama sekali buat server game saya.', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Andi Wijaya', comment: 'Harga paling bersahabat dibanding toko sebelah. Mantap Baeci Store!', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Dewi Lestari', comment: 'Langganan terus di sini, ga pernah mengecewakan. Sukses terus ya!', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Eko Prasetyo', comment: 'Pelayanan bintang 5! Respon cepet, barang langsung dikirim.', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Lia Putri', comment: 'Suka banget belanja di sini, aman dan terpercaya banget pokoknya.', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Hendra', comment: 'Top markotop! Udah order berkali-kali tetep konsisten pelayanannya.', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Rina', comment: 'Testimoni jujur: emang beneran bagus pelayanannya. Ga nyesel beli di sini.', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' },
      { name: 'Fajar', comment: 'Sangat membantu buat yang cari produk digital murah tapi berkualitas.', rating: 5, photo: 'https://k.top4top.io/p_3684algta8.jpg' }
    ];

    if (!existing) {
      await settings.insertOne({
        type: 'web_config',
        webName: 'Biolink Cute',
        profilePhoto: 'https://files.catbox.moe/u6vj2i.png',
        backgroundPhoto: 'https://files.catbox.moe/u6vj2i.png',
        musicUrl: 'https://files.catbox.moe/5n5l9z.mp3',
        links: defaultLinks,
        payments: defaultPayments,
        testimonials: defaultTestimonials,
        qrisUrl: 'https://f.top4top.io/p_3684ji47a0.jpg'
      });
    }
    
    // Ensure existing configs have these fields or update them with new realistic data
    await settings.updateOne(
      { type: 'web_config' },
      { $set: { testimonials: defaultTestimonials } }
    );
    
    return db;
  } catch (err) {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  }
}
/*
• Jasa pembuatan website 
• Menerima perbaikan script atau fitur bot
• Menerima pembuatan fitur bot
• Menerima semua kebutuhan bot
• Menerima dia dengan segala kekurangannya;)
ℹ️ Information

• Bisa bayar di awal atau akhir
• Pembayaran melalu QRIS Only
• Testimoni Banyak

Kontak: wa.me/6282389924037
t.me/VynaaValerie
*/
module.exports = { connectDB };